package com.cg.importedorder.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.importedorder.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order,Integer>{

	@Query("from Order order where order.quantity between :quantity and :quantity1")
	List<Order> findByPrice(@Param("quantity")int quantity,@Param("quantity1") int quantity1);

	@Query("from Order where amount > :amo")
	List<Order> getByAmount(@Param("amo") double amount);
	

}

