package com.cg.importedorder.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ImportedOrder")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=01, allocationSize=500, sequenceName = "prod_id")
    @Column(name="id", updatable=false, nullable=false)  
	private int id;
	private double price;
	private int quantity;
	private double amount;
	private double charges;
	

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Order(int id, double price, int quantity, double amount, double charges) {
		super();
		this.id = id;
		this.price = price;
		this.quantity = quantity;
		this.amount = amount;
		this.charges = charges;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getCharges() {
		return charges;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	
	
	@Override
	public String toString() {
		return "Order [id=" + id + ", price=" + price + ", quantity=" + quantity + ", amount=" + amount + ", charges="
				+ charges + "]";
	}
	
	

}
