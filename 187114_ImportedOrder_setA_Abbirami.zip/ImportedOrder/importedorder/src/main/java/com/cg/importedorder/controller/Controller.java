package com.cg.importedorder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.importedorder.entity.Order;
import com.cg.importedorder.exception.QuantityException;
import com.cg.importedorder.service.OrderService;

@RestController
public class Controller {
	
	@Autowired
	OrderService service;
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public List<Order> addOrder( @RequestBody Order order) throws QuantityException{
		return service.addOrder(order);
	}
	
	  @PutMapping("/update/{id}")
	    public List<Order> UpdateOrder(@PathVariable int id, @RequestBody Order order)  throws QuantityException {
	        return service.UpdateOrder(id, order);
	    }
	  
	  @RequestMapping(value="/viewallproducts")
		public List<Order> getAllOrders(){
			return service.getAllOrders(); 
			
		}
	  
	  
	   @RequestMapping("/quantityrange/{quantity}/{quantity1}")
		public List <Order> getOrderByQuantityRange(@PathVariable int quantity,@PathVariable int quantity1) {
		return service.getOrderByQuantityRange(quantity,quantity1);
	    }

	   @RequestMapping("/amount/{amount}")
		public List <Order> getOderByAmount(@PathVariable double amount){
		return service.getOderByAmount(amount);
	    }
	

}
