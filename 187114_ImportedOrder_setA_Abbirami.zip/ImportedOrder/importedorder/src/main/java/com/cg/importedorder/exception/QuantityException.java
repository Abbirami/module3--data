package com.cg.importedorder.exception;

public class QuantityException extends Exception {
	
	public QuantityException() {
		super();
	}
	
	public QuantityException(String msg) {
		super(msg);
	}

}
