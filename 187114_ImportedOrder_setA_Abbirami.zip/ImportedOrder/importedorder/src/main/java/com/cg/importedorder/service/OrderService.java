package com.cg.importedorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.importedorder.entity.Order;
import com.cg.importedorder.exception.QuantityException;
import com.cg.importedorder.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	OrderRepository repoObj;

	public List<Order> addOrder(Order order)  throws QuantityException {
		// TODO Auto-generated method stub
		try {
		double price1=order.getPrice() * 75;
       double total=order.getQuantity() * price1;
       order.setAmount(total);
		double chargeamount=total*(0.0125);
		order.setCharges(chargeamount);
		repoObj.save(order);
		return repoObj.findAll();
	}catch(Exception e) {
		throw new QuantityException(e.getMessage());
	}
	}

	public List<Order> UpdateOrder(int id, Order order)  throws QuantityException{
		// TODO Auto-generated method stub
		try {
		 Optional<Order> optional=repoObj.findById(id);
	        if(optional.isPresent())
	        {
	            Order orderObj=optional.get();
	            orderObj.setId(order.getId());
	            orderObj.setPrice(order.getPrice());
	            orderObj.setQuantity(order.getQuantity());
	        	double price1=order.getPrice() * 75;
	            double total=order.getQuantity() * price1;
	            orderObj.setAmount(total);
	     		double chargeamount=total*(0.0125);
	     		orderObj.setCharges(chargeamount);
	           /* orderObj.setAmount(order.getAmount());
	            orderObj.setCharges(order.getCharges());
	            double total=order.getPrice()*order.getQuantity();
	            order.setAmount(total);*/
	            repoObj.save(orderObj);
	        
	           
	        }
		return getAllOrders(); }
		catch(Exception e)
		{
			throw new QuantityException(e.getMessage());
		}
	}

	public List<Order> getAllOrders() {
		// TODO Auto-generated method stub
		return repoObj.findAll();
	}

	public List<Order> getOrderByQuantityRange(int quantity, int quantity1) {
		// TODO Auto-generated method stub
		return repoObj.findByPrice(quantity,quantity1);
	}

	public List<Order> getOderByAmount(double amount) {
		// TODO Auto-generated method stub
		return repoObj.getByAmount(amount);
	}
	

}
