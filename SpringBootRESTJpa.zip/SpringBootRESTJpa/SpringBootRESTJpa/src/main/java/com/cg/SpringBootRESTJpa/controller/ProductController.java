package com.cg.SpringBootRESTJpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SpringBootRESTJpa.beans.Product;
import com.cg.SpringBootRESTJpa.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	@RequestMapping(value="/products")
	public List<Product> getAllProducts() {
		return productService.getAllProducts(); 
		
	}
	
	@RequestMapping(value="/product",method=RequestMethod.POST)
	public List<Product> addProduct(@RequestBody Product pro) {
		return productService.addProduct(pro);
	}
	
	@RequestMapping("/products/{id}")
	public Product getProductById(@PathVariable String id)  {
		return productService.getProductById(id);
	}
	
	@DeleteMapping("/products/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable String id) {
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Book with id "+id+" deleted",HttpStatus.OK);
	}
	
	  @PutMapping("/products/{id}")
	    public List<Product> UpdateProduct(@PathVariable String id, @RequestBody Product pro) {
	        return productService.UpdateProduct(id, pro);
	    }

}
