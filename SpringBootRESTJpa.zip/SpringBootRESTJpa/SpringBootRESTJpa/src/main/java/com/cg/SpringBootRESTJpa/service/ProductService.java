package com.cg.SpringBootRESTJpa.service;

import java.util.List;

import com.cg.SpringBootRESTJpa.beans.Product;

public interface ProductService {

	public List<Product> getAllProducts();

	public List<Product> addProduct(Product pro);

	public Product getProductById(String id);

	public void deleteProduct(String id);
	
	public List<Product> UpdateProduct(String id,Product pro);

}
