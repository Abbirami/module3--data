package com.cg.SpringBootRESTJpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRESTJpa.beans.Product;
import com.cg.SpringBootRESTJpa.dao.ProductDao;



@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao productDao;

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
		/*
		try
		{
			return productRepo.findAll();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}*/
	
	}

	@Override
	public List<Product> addProduct(Product pro) {
		// TODO Auto-generated method stub
		
		productDao.save(pro);
		return productDao.findAll();
		/*try {
			productDao.save(pro);
			return productDao.findAll();
		}catch(Exceptio e) {
			throw new ProductException(e.getMssage());
		}*/
		
	}

	@Override
	public Product getProductById(String id) {
		// TODO Auto-generated method stub\
		
		return productDao.findById(id).get();
	/*	try
		{
			return productRepo.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new ProductException(ex.getMessage());
		}*/
	}

	@Override
	public void deleteProduct(String id) {
		// TODO Auto-generated method stub
		productDao.deleteById(id);
		/*try {
		productDao.deleteById(pro);
	}catch(Exceptio e) {
		throw new ProductException(e.getMssage());
	}*/
		
	}

	@Override
	public List<Product> UpdateProduct(String id, Product pro) {
		// TODO Auto-generated method stub
		//public List<Product> updateProduct(String id, Product pro) {

			 


	        Optional<Product> optional=productDao.findById(id);
	        if(optional.isPresent())
	        {
	            Product product=optional.get();
	            product.setName(pro.getName());
	            product.setModel(pro.getModel());
	            product.setPrice(pro.getPrice());
	            
	            productDao.save(product);
	        }
	    
	        
	        return getAllProducts();

	 


	    }
	/*	try
		{
			Optional<Product> optional=productRepo.findById(id);
			if(optional.isPresent())
			{
				Product product=optional.get();
				product.setName(pro.getName());
				product.setModel(pro.getModel());
				product.setPrice(pro.getPrice());
				productRepo.save(product);
				return getAllProducts();
			}
			else
			{
				throw new ProductException("Product with Id"+id+" is not  existing please enter an valid id ");	
			}
		}
			catch(Exception e) {
	            throw new ProductException(e.getMessage());
			
	}*/
	}


